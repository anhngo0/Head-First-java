package tictoe_game;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;

import javax.swing.JButton;

public class TictoeBtn extends JButton{
    private String side = null;
    private int value = -1;

    public TictoeBtn(){
        setBackground(new Color(204,204 ,204,204));
        setFont(new Font("MV Boli", Font.BOLD, 120));
        setFocusable(false);
    }
    public void setRedBtn(){
        side = "Red";
        value = 1;
        setForeground(new Color(255,0,0));
        setText("X");
    }
    public void setBlueBtn(){
        side = "Blue";
        value = 0;
        setForeground(new Color(0,0,255));
        setText("O");
    }
    public String getSide(){
        return side;
    }
    public int getValue(){
        return value;
    }
}
