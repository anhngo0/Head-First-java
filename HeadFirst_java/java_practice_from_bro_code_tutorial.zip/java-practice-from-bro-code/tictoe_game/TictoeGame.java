package tictoe_game;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;

public class TictoeGame implements ActionListener{
    Random random = new Random();
    JFrame frame = new JFrame();
    JPanel title_panel = new JPanel();
    JPanel button_panel = new JPanel();
    JLabel textfield = new JLabel();
    TictoeBtn[] buttons = new TictoeBtn[9];
    boolean player1_turn = false;
    final int[][]WINNING_SEQUENCE = {
        {0,1,2} , {3,4,5}, {6,7,8},
        {0,3,6} , {1,4,7}, {2,5,8},
        {0,4,8} , {2,3,6}
};

    public TictoeGame(){
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800,800);
        frame.getContentPane().setBackground(new Color(50,50,50));
        frame.setLayout(new BorderLayout());

        textfield.setBackground(new Color(25,25,25));
        textfield.setForeground(new Color(25, 255, 0));
        textfield.setFont(new Font("Ink Free", Font.BOLD, 75));
        textfield.setHorizontalAlignment(JLabel.CENTER);
        textfield.setText("Tic-Tac-Toe");
        textfield.setOpaque(true);

        title_panel.setLayout(new BorderLayout());
        title_panel.setBounds(0, 0, 800, 100);

        button_panel.setLayout(new GridLayout(3,3,4,4));
        button_panel.setBackground(new Color(150,150,150));

        for(int i = 0;i < 9; i++){
            buttons[i] = new TictoeBtn();
            buttons[i].addActionListener(this);
            button_panel.add(buttons[i]);
        }

        title_panel.add(textfield);
        frame.add(title_panel, BorderLayout.NORTH);
        frame.add(button_panel);

        firstTurn();
        frame.setVisible(true);
    }
   
    public void actionPerformed(ActionEvent e){
        for(int i = 0; i < 9; i++){
            if(e.getSource()==buttons[i]){
                if(player1_turn){
                    if(buttons[i].getText()==""){
                        buttons[i].setRedBtn();
                        player1_turn=false;
                        textfield.setText("Blue turn");
                        check();
                    }
                } else{
                    if(buttons[i].getText()==""){
                        buttons[i].setBlueBtn();
                        player1_turn=true;
                        textfield.setText("Red turn");
                        check();

                    }
                }
            }
        }
    }
    public void firstTurn(){
        try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		if(random.nextInt(2)==0) {
			player1_turn=true;
			textfield.setText("X turn");
		}
		else {
			player1_turn=false;
			textfield.setText("O turn");
		}
    }
    public void check(){
        
        for(int[] sequence: WINNING_SEQUENCE){
            if(buttons[sequence[0]].getValue() != -1
            && buttons[sequence[0]].getValue() == buttons[sequence[1]].getValue()
            && buttons[sequence[0]].getValue() == buttons[sequence[2]].getValue())
            {
                buttons[sequence[0]].setBackground(Color.GREEN);
                buttons[sequence[1]].setBackground(Color.GREEN);
                buttons[sequence[2]].setBackground(Color.GREEN);
                
                for(int i=0;i<9;i++) {
                    buttons[i].setEnabled(false);
                }
                textfield.setText(buttons[sequence[0]].getSide() +" wins");
            }
        }
    }
}

