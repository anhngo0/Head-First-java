package Stop_Watch;

public class Main {
    public static void main(String[] args) {
        StopWatch app = new StopWatch();
    }
}
