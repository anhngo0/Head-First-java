package Quiz_App;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.Timer;

public class Quiz_App {
	String[] questions = { "Which company created Java?", "Which year was Java created?",
			"What was Java originally called?", "Who is credited with creating Java?" };
	String[][] options = { { "Sun Microsystems", "Starbucks", "Microsoft", "Alphabet" },
			{ "1989", "1996", "1972", "1492" }, { "Apple", "Latte", "Oak", "Koffing" },
			{ "Steve Jobs", "Bill Gates", "James Gosling", "Mark Zuckerburg" } };
	char[] answers = { 'A', 'B', 'C', 'C' };
	String[] answersChar = { "A", "B", "C", "D" };

	int seconds = 10;      //to count down time left
	int total_questions = questions.length;
	int correct_guesses = 0;
	int questionCount = 0;
	boolean isAnswerChosen = false;
	int answerChosenIndex; // the index of answer we clicked into

	JFrame frame = new JFrame();
	JPanel qaPanel = new JPanel();
	JTextField textField = new JTextField();
	JTextArea textArea = new JTextArea();
	JLabel time_label = new JLabel();
	JLabel seconds_left = new JLabel();
	Option_Panel[] optionsPanel = new Option_Panel[4];
	JTextField number_right = new JTextField();
	JTextField percentage = new JTextField();

	Timer countDown = new Timer(1000, new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			--seconds;
			seconds_left.setText(String.valueOf(seconds));
			if (seconds <= 0) {
				displayAnswer();
			}
		}
	});

	public Quiz_App() {
		setupFrame();
		displayDataEachQuestion();
	}

	public void setupFrame() {
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(650, 650);
		frame.getContentPane().setBackground(new Color(50, 50, 50));
		frame.getContentPane().setLayout(null);
		frame.setResizable(false);

		textField.setBounds(0, 0, 650, 50);
		textField.setBackground(new Color(25, 25, 25));
		textField.setForeground(new Color(25, 255, 0));
		textField.setFont(new Font("Ink Free", Font.BOLD, 30));
		textField.setBorder(BorderFactory.createBevelBorder(1));
		textField.setHorizontalAlignment(JTextField.CENTER);
		textField.setEditable(false);

		textArea.setBounds(0, 50, 650, 50);
		textArea.setLineWrap(true);
		textArea.setWrapStyleWord(true);
		textArea.setBackground(new Color(25, 25, 25));
		textArea.setForeground(new Color(25, 255, 0));
		textArea.setFont(new Font("MV Boli", Font.BOLD, 25));
		textArea.setBorder(BorderFactory.createBevelBorder(1));
		textArea.setEditable(false);

		seconds_left.setBounds(535, 510, 100, 100);
		seconds_left.setBackground(new Color(25, 25, 25));
		seconds_left.setForeground(new Color(255, 0, 0));
		seconds_left.setFont(new Font("Ink Free", Font.BOLD, 60));
		seconds_left.setBorder(BorderFactory.createBevelBorder(1));
		seconds_left.setOpaque(true);
		seconds_left.setHorizontalAlignment(JTextField.CENTER);
		seconds_left.setText(String.valueOf(seconds));

		time_label.setBounds(535, 485, 100, 25);
		time_label.setBackground(new Color(50, 50, 50));
		time_label.setForeground(new Color(255, 0, 0));
		time_label.setFont(new Font("MV Boli", Font.PLAIN, 16));
		time_label.setHorizontalAlignment(JTextField.CENTER);
		time_label.setText("timer >:D");

		qaPanel.setBounds(0, 110, 650, 400);
		qaPanel.setLayout(new GridLayout(4, 1));
		
		number_right.setBounds(225,225,200,100);
		number_right.setBackground(new Color(25,25,25));
		number_right.setForeground(new Color(25,255,0));
		number_right.setFont(new Font("Ink Free",Font.BOLD,50));
		number_right.setBorder(BorderFactory.createBevelBorder(1));
		number_right.setHorizontalAlignment(JTextField.CENTER);
		number_right.setEditable(false);
		
		percentage.setBounds(225,325,200,100);
		percentage.setBackground(new Color(25,25,25));
		percentage.setForeground(new Color(25,255,0));
		percentage.setFont(new Font("Ink Free",Font.BOLD,50));
		percentage.setBorder(BorderFactory.createBevelBorder(1));
		percentage.setHorizontalAlignment(JTextField.CENTER);
		percentage.setEditable(false);

		for (int i = 0; i < 4; i++) {
			optionsPanel[i] = new Option_Panel(answersChar[i]);
			optionsPanel[i].getButton().addActionListener(new ButtonsHandledEvent());
			optionsPanel[i].getButton().setText(answersChar[i]);
			qaPanel.add(optionsPanel[i]);
		}

		frame.add(time_label);
		frame.add(seconds_left);
		frame.add(qaPanel);
		frame.add(textField);
		frame.add(textArea);
		frame.setVisible(true);
	}

	public void displayDataEachQuestion() {
		isAnswerChosen = false;
		textArea.setText(questions[questionCount]);
		for (int i = 0; i < answersChar.length; i++) {
			optionsPanel[i].resetState();
			optionsPanel[i].setOptionText(options[questionCount][i]);
		}
		textField.setText("Question" + (questionCount + 1));
		countDown.start();
	}

	public void displayAnswer() {
		countDown.stop();
		
		for (int i = 0; i < answersChar.length; i++) {
			if (Character.toString(answers[questionCount]).equals(answersChar[i])) {
				optionsPanel[i].setState_Right();
				continue;
			}
//			Check if any button is click then set to wrong state, else 
//			set the button to the not chosen state
			if (isAnswerChosen && (answerChosenIndex == i)) {
				optionsPanel[i].setState_Wrong();
			} else {
				optionsPanel[i].setState_NotChosen();
			}
		}
		questionCount++;
		Timer pause = new Timer(2000, new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if(questionCount == total_questions) {
					showResult();
					return;
				}
				seconds = 10;
				seconds_left.setText(String.valueOf(seconds));
				displayDataEachQuestion();
			}
		});
		pause.setRepeats(false);
		pause.start();
	}

	public void showResult() {
	    int result = (int)((correct_guesses/(double)total_questions)*100);
		
		textField.setText("RESULTS!");
		textArea.setText("");
		
		number_right.setText("("+correct_guesses+"/"+total_questions+")");
		percentage.setText(result+"%");
		
		frame.add(number_right);
		frame.add(percentage);
	}
	
	public class ButtonsHandledEvent implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			for (int i = 0; i < answersChar.length; i++) {
				if(e.getSource() == optionsPanel[i].getButton()) {
					answerChosenIndex = i;
					if(Character.toString(answers[questionCount]).equals(answersChar[answerChosenIndex])) {
						correct_guesses++;
					}
				}
			}
			isAnswerChosen = true;
			displayAnswer();
		}
	}
}
