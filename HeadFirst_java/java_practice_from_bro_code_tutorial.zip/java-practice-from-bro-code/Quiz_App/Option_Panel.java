package Quiz_App;

import java.awt.Color;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Option_Panel extends JPanel {
	final int PANEL_WIDTH = 650;
	final int PANEL_HEIGHT = 100;
	final int BUTTON_WIDTH = 100;
	final String[] STATE = { "wrong", "not chosen", "right" };

	JButton optionBtn;
	JLabel optionText;
	String state = null;
	// String answer = null;

	public Option_Panel(String optionAnswer) {
		this.setSize(PANEL_WIDTH, PANEL_HEIGHT);
		// setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
		this.setLayout(null);
		this.setBackground(new Color(50, 50, 50));

		optionBtn = new JButton();
		optionBtn.setText(optionAnswer);
		optionBtn.setSize(BUTTON_WIDTH, PANEL_HEIGHT);
		optionBtn.setFocusable(false);
		optionBtn.setLocation(0, 0);

		optionText = new JLabel();
		optionText.setSize(PANEL_WIDTH - BUTTON_WIDTH, PANEL_HEIGHT);
		optionText.setLocation(BUTTON_WIDTH, 0);
		optionText.setAlignmentY(JPanel.CENTER_ALIGNMENT);
		optionText.setBackground(new Color(50, 50, 50));
		optionText.setForeground(new Color(25, 255, 0));
		optionText.setFont(new Font("MV Boli", Font.PLAIN, 35));

		add(optionBtn);
		add(optionText);
	}

	// get button function to get action event when click
	public JButton getButton() {
		return optionBtn;
	}

	// put text option
	public void setOptionText(String message) {
		optionText.setText(message);
	}

	public void setState_Wrong() {
		state = STATE[0];
		revealedOption();
	}

	public void setState_NotChosen() {
		state = STATE[1];
		revealedOption();
	}

	public void setState_Right() {
		state = STATE[2];
		revealedOption();
	}

	private void revealedOption() {
		if (state.equals(STATE[0])) {
			optionText.setForeground(new Color(250, 0, 0));
		}
		if (state.equals(STATE[1])) {
			optionText.setForeground(new Color(32, 32, 32));
		}
		if (state.equals(STATE[2])) {
			optionText.setForeground(new Color(0, 250, 0));
		}
		this.setEnabled(false);
	}

	public void resetState() {
		state = null;
		this.setEnabled(true);
		optionText.setForeground(new Color(0, 250, 0));
	}
	// public String getAnswer(){
	// return answer;
	// }
	// private void setAnswer(){
	// answer = optionBtn.getText();
	// }
}
