package Quiz_App;

public class Main {
    public static void main(String[] args) {
        Quiz_App app = new Quiz_App();
    }
}
