package clock_app;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class ClockApp extends JFrame{
    Calendar calendar;
    JLabel timeLabel;
    JLabel dayLabel;
    JLabel dateLabel;
    SimpleDateFormat timeFormat;
    SimpleDateFormat dayFormat;
    SimpleDateFormat dateFormat;
    String time;
    String day;
    String date;

    public static void main(String[] args) {
        ClockApp app = new ClockApp();
    }
    public ClockApp(){
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setLocationRelativeTo(null);
        setSize(350,200);
        setLayout(new FlowLayout());
        setTitle("My clock program");

        timeFormat = new SimpleDateFormat("hh:mm:ss:z");
        dayFormat = new SimpleDateFormat("EEEE");
        dateFormat = new SimpleDateFormat("MMMMMM dd,yyyy");

        timeLabel = new JLabel();
        timeLabel.setFont(new Font("Verdana", Font.PLAIN, 50));
        timeLabel.setForeground(new Color(0x00FF00));
        timeLabel.setBackground(Color.black);
        timeLabel.setOpaque(true);

        dayLabel = new JLabel();
        dayLabel.setFont(new Font("lnk Free", Font.PLAIN, 25));

        dateLabel = new JLabel();
        dateLabel.setFont(new Font("lnk Free",Font.PLAIN, 25));

        add(timeLabel);
        add(dayLabel);
        add(dateLabel);
        setVisible(true);
        setTime();
    }

    public void setTime(){
        while(true){
            time = timeFormat.format(Calendar.getInstance().getTime());
            timeLabel.setText(time);

            day = dayFormat.format(Calendar.getInstance().getTime());
            dayLabel.setText(day);

            date = dateFormat.format(Calendar.getInstance().getTime());
            dateLabel.setText(date);
            try{
                Thread.sleep(1000);
            } catch(InterruptedException  e){
                e.printStackTrace();
            }
        }
    }
}
